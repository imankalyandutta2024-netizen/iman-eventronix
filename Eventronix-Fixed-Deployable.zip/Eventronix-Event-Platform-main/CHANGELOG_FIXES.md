# Eventronix repair notes

## Corrected
- Replaced invalid requirements entry `python-3.10.0` with a separate supported Python runtime declaration; removed unused and expensive scikit-learn dependency.
- Added `.env.example`, Dockerfile, Docker Compose, Render deployment Blueprint, requirements for tests, ignore files, and GitHub CI.
- Required a persistent secret key for production and restricted CORS to explicitly configured origins.
- Added `/healthz` liveness and `/readyz` database connectivity endpoints.
- Fixed signup detection on `/signup`, error reporting, redirect logic, and session persistence.
- Introduced authorization and safe ObjectId/JSON validation, ownership-based organizer isolation, and serialized Mongo IDs/dates.
- Prevented overflowing or already-submitted teams from being joined; added team ownership checks to submission and join-request approval.
- Fixed accepting AI join requests from inadvertently granting membership to pending users.
- Replaced nonexistent Socket.IO backend integration with authenticated MongoDB-backed chat, polls, whiteboard drawing, and polling.
- Fixed broken collaboration JS paths, missing team selector on standalone collaboration pages, multiple dashboard global conflicts, and a top-level JavaScript ReferenceError.
- Fixed individual event registration pages (notably hackathon create/join/AI match), local event deadline timezone handling, and common dashboard content clearing.
- Escaped dynamic user-provided HTML and added basic poll and message validation.
- Added integration tests using mongomock, and GitHub CI to execute the tests in a provisioned environment.

## Verification status
- **Performed:** Python AST/bytecode syntax check; Node `--check` on all frontend JS and 12 inline scripts; local JS source existence audit; YAML parse; ZIP integrity verification.
- **Not performed in sandbox:** Flask HTTP integration test, live MongoDB or browser e2e test, hosted Render/Docker deployment. This sandbox has no Flask/mongomock installation and package downloads were unavailable. Run `pip install -r requirements-dev.txt && pytest -q` or GitHub CI after extracting.

## Existing functional constraints
- A live MongoDB server/Atlas cluster and appropriate environment variables are required for business functionality.
- Legacy events lack the new `organizerEmail` ownership field; importers of old databases must backfill ownership for organizer access.
- Hosted/prod use should add rate limiting, CSRF protection, backup policies, account verification, DB transactions for multi-document updates, audit logs and production monitoring.
