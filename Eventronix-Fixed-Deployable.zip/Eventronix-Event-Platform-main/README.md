# Eventronix — Event Management Platform 🎉

A Flask + MongoDB web application with organizer and participant accounts, event registration, hackathon teams, skill-based team suggestions, registration analytics, CSV export, chat, polls and a collaborative whiteboard. The HTML/CSS/JavaScript frontend is served by the same Flask process as the REST API.

## Quick start: Docker (recommended)

1. Install Docker and the Docker Compose plugin.
2. Copy `.env.example` to `.env`. Set `SECRET_KEY` to a unique long random string (for example `python -c "import secrets; print(secrets.token_hex(32))"`). Do **not** commit `.env`.
3. In the repository root, run:

   ```bash
   docker compose up --build -d
   ```

4. Visit **http://localhost:5000**. Docker starts MongoDB and persists its data in a named volume. Create an **organizer** account, sign in, and create an event. Register a **participant** account to join it.
5. Check `http://localhost:5000/healthz` (web server alive) and `http://localhost:5000/readyz` (MongoDB reachable).

To stop, use `docker compose down`. Avoid `docker compose down -v` unless you intend to delete the database.

## Run without Docker

Requires Python **3.11+** and MongoDB. From the repository root:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env  # Or manually copy on Windows
# Edit SECRET_KEY, MONGO_URI, and FLASK_DEBUG in .env.
python -m backend.app
```

Access `http://127.0.0.1:5000`. Set `FLASK_DEBUG=false` in production. Local Mongo URI is `mongodb://localhost:27017/eventronix`.

## Render deployment

1. Push this repository to your own Git provider, connect it to Render, and choose **Blueprint** using `render.yaml` (or create a Python Web Service with `pip install -r requirements.txt` and `gunicorn --workers 2 --bind 0.0.0.0:$PORT backend.app:app`).
2. Provision MongoDB Atlas **separately**: Render's web service does not include MongoDB. Add its connection string as the **secret** `MONGO_URI`, including a database name, e.g. `mongodb+srv://.../eventronix?retryWrites=true&w=majority`. Allow connectivity from Render on the Atlas network access list. Do not hardcode secrets.
3. Render generates `SECRET_KEY` for Blueprint deployments. Set `SESSION_COOKIE_SECURE=true` on HTTPS.
4. Confirm both `/healthz` and `/readyz` return 200. `/readyz` will report 503 if MongoDB is unreachable.
5. Python version is set to 3.11.11 in `render.yaml`. Free tier sleep/cold-start behavior depends on Render's current plan; background polling uses ordinary HTTPS rather than WebSockets.

## Configuration

| Environment variable | Meaning |
| --- | --- |
| `SECRET_KEY` | **Required** outside debug/test mode. Set one unique, persistent, high-entropy value. |
| `MONGO_URI` | MongoDB connection string; defaults to localhost for development. **Required in hosted environments.** |
| `PORT` | Flask development port (default 5000). Gunicorn binds to `$PORT` on Render. |
| `FLASK_DEBUG` | Set `true` only for local development. |
| `SESSION_COOKIE_SECURE` | Set `true` for HTTPS production deployments; `false` for localhost. |
| `CORS_ORIGINS` | Optional comma-separated explicitly allowed origins; same-origin UI needs none. |

## Tests

```bash
pip install -r requirements-dev.txt
pytest -q
```

Tests use `mongomock`: no external MongoDB is needed for the API test suite. They exercise signup, sessions, organizer permissions, event creation, registrations, team capacity, join requests, chat, polls and whiteboard endpoints. **Also perform a real MongoDB + browser smoke test before accepting production traffic.**

## Main routes

- Pages: `/`, `/signin`, `/signup`, `/organizer_dashboard`, `/participant_dashboard`, `/virtual_event`, `/event_pages/*.html`
- Health: `GET /healthz` and `GET /readyz`
- Auth: `POST /signup`, `POST /signin`, `POST /logout`, `GET /auth/check_session`
- Organizer: `/organizer/create_event`, `/organizer/events`, `/organizer/<eventId>/{participants,teams,analytics,export,ai_roadmap,submitted_teams}`
- Participant: `/participant/events`, `/participant/register`, `/participant/register_hackathon`, `/participant/teams/<eventId>`, `/participant/ai_match_request`
- Team requests/status: `/participant/team/<teamId>/status`, `/participant/team/<teamId>/requests`, `/participant/request/<requestId>/accept`, `/participant/request/<requestId>/reject`
- Collaboration: `/collaboration/chat/<teamId>`, `/collaboration/poll/<teamId>`, `/collaboration/vote/<pollId>`, `/collaboration/whiteboard/<teamId>`

## Implementation notes / limitations

- Organizer events are scoped to the organizer who created them. Records created before this ownership field existed (`organizerEmail`) require a **one-time ownership migration** if importing an older MongoDB database.
- Team access is tied to the signed-in account email. Only a team creator can approve or reject join requests. Team codes are visible to members, not to unrelated accounts.
- The "AI team match" is a lightweight token/TF–IDF-like **heuristic**, not a generative AI service.
- Collaboration uses polling every 2.5 seconds while the page is visible; **not** a realtime Socket.IO implementation. This works with ordinary WSGI hosts, but large deployments would benefit from a realtime transport and rate limits.
- The provided organizer interface converts local browser deadlines to UTC ISO 8601 timestamps. Direct API callers should include explicit UTC offsets; offset-free API timestamps are interpreted as UTC.
- This is a deployable prototype, **not** a security-audited enterprise system. Before high-volume/public use, add CSRF protection, rate limiting, managed secrets, email verification, automated backup strategy, database transactions for multi-document joins and production observability.

## Attribution

Maintains the original Eventronix frontend/layout and Flask + MongoDB architecture. See the original repository's credits for its creators.
