"""Integration tests using a disposable in-memory MongoDB."""
import os
os.environ['SECRET_KEY'] = 'pytest-only-strong-test-signing-key'

import pytest
import mongomock
from backend.app import app
from backend.config import mongo


@pytest.fixture()
def db(monkeypatch):
    client = mongomock.MongoClient()
    database = client['eventronix_tests']
    monkeypatch.setattr(mongo, 'db', database)
    app.config.update(TESTING=True, SECRET_KEY=os.environ['SECRET_KEY'])
    yield database
    client.close()


@pytest.fixture()
def client(db):
    return app.test_client()


def signup(client, email, role):
    return client.post('/signup', json={'email': email, 'password': 'long-enough-password', 'role': role})


def login(client, email):
    return client.post('/signin', json={'email': email, 'password': 'long-enough-password'})


def event(client, size=2, kind='hackathon'):
    response = client.post('/organizer/create_event', json={'name': 'Autumn Fest', 'type': kind, 'teamSize': size})
    assert response.status_code == 201, response.json
    return response.json['eventId']


def test_frontend_routes_and_health(client):
    for path in ('/', '/signin', '/signup', '/organizer_dashboard', '/participant_dashboard', '/virtual_event',
                 '/assets/js/main.js', '/event_pages/hackathon.html', '/collaboration/chat.html'):
        assert client.get(path).status_code == 200, path
    assert client.get('/healthz').json == {'status': 'ok'}
    assert client.get('/not-a-real-page').status_code == 404
    assert client.get('/assets/../backend/config.py').status_code == 404


def test_signup_login_role_and_session(client):
    assert signup(client, 'orga@example.org', 'organizer').status_code == 201
    assert signup(client, 'orga@example.org', 'organizer').status_code == 409
    assert client.post('/signup', json={'email': 'invalid', 'password': 'short', 'role': 'hacker'}).status_code == 400
    assert login(client, 'orga@example.org').status_code == 200
    assert client.get('/auth/check_session').json['user']['role'] == 'organizer'
    assert client.post('/logout').status_code == 200
    assert client.get('/auth/check_session').json == {'loggedIn': False}
    assert client.post('/organizer/create_event', json={'name': 'X', 'type': 'hackathon'}).status_code == 401


def test_organizer_create_and_owner_isolation(client, db):
    signup(client, 'a@example.org', 'organizer')
    login(client, 'a@example.org')
    event_id = event(client)
    assert len(client.get('/organizer/events').json) == 1
    assert client.get(f'/organizer/event/{event_id}').status_code == 200
    assert client.get(f'/organizer/{event_id}/analytics').json == {'participant_count': 0, 'team_count': 0}
    client.post('/logout')
    signup(client, 'b@example.org', 'organizer')
    login(client, 'b@example.org')
    assert client.get('/organizer/events').json == []
    assert client.get(f'/organizer/event/{event_id}').status_code == 403
    assert client.get('/organizer/event/not-valid').status_code == 400
    assert client.get(f'/organizer/{event_id}/export').status_code == 403


def test_registration_and_capacity(client, db):
    signup(client, 'owner@example.org', 'organizer')
    login(client, 'owner@example.org')
    event_id = event(client, size=2)
    client.post('/logout')
    signup(client, 'p1@example.org', 'participant')
    login(client, 'p1@example.org')
    owner = client.post('/participant/register_hackathon', json={'eventId': event_id, 'name': 'A', 'phone': '123',
                                                                  'action': 'create', 'teamName': 'Team One'})
    assert owner.status_code == 201, owner.json
    team_id, code = owner.json['teamId'], owner.json['teamCode']
    assert len(code) == 8
    assert client.post('/participant/register', json={'eventId': event_id, 'name': 'A', 'phone': '123'}).status_code == 409
    assert client.get(f'/participant/teams/{event_id}').json[0]['teamCode'] == code
    client.post('/logout')
    signup(client, 'p2@example.org', 'participant')
    login(client, 'p2@example.org')
    teams = client.get(f'/participant/teams/{event_id}').json
    assert 'teamCode' not in teams[0]
    join = client.post('/participant/register_hackathon', json={'eventId': event_id, 'name': 'B', 'phone': '456',
                                                                 'action': 'join', 'teamCode': code})
    assert join.status_code == 200, join.json
    assert client.get(f'/participant/team/{team_id}/status').status_code == 200
    assert client.post(f'/participant/team/{team_id}/submit', json={}).status_code == 200
    assert client.get(f'/participant/team/{team_id}/status').json['submitted'] is True
    client.post('/logout')
    signup(client, 'p3@example.org', 'participant')
    login(client, 'p3@example.org')
    assert client.post('/participant/register_hackathon', json={'eventId': event_id, 'name': 'C', 'phone': '789',
                                                                'action': 'join', 'teamCode': code}).status_code == 409
    assert client.get(f'/participant/team/{team_id}/status').status_code == 403


def test_chat_poll_vote_whiteboard(client, db):
    signup(client, 'org@example.org', 'organizer')
    login(client, 'org@example.org')
    event_id = event(client, size=4)
    client.post('/logout')
    signup(client, 'p@example.org', 'participant')
    login(client, 'p@example.org')
    team_id = client.post('/participant/register_hackathon', json={'eventId': event_id, 'name': 'P',
                              'phone': '100', 'action': 'create', 'teamName': 'Developers'}).json['teamId']
    assert client.post(f'/collaboration/chat/{team_id}', json={'message': 'Hello'}).status_code == 201
    assert client.get(f'/collaboration/chat/{team_id}').json[0]['message'] == 'Hello'
    assert client.post(f'/collaboration/poll/{team_id}', json={'question': 'Which?', 'options': ['A', 'B']}).status_code == 201
    poll_id = client.get(f'/collaboration/poll/{team_id}').json[0]['_id']
    assert client.post(f'/collaboration/vote/{poll_id}', json={'optionIndex': 1}).status_code == 200
    assert client.post(f'/collaboration/vote/{poll_id}', json={'optionIndex': 1}).status_code == 409
    assert client.post(f'/collaboration/vote/{poll_id}', json={'optionIndex': 100}).status_code == 400
    assert client.get(f'/collaboration/poll/{team_id}').json[0]['votes'] == [0, 1]
    stroke = {'x1': 0, 'y1': 1, 'x2': 2, 'y2': 3, 'color': 'black', 'size': 3}
    assert client.post(f'/collaboration/whiteboard/{team_id}', json=stroke).status_code == 201
    assert len(client.get(f'/collaboration/whiteboard/{team_id}').json) == 1
    assert client.delete(f'/collaboration/whiteboard/{team_id}').status_code == 200
    assert client.get(f'/collaboration/whiteboard/{team_id}').json == []
    client.post('/logout')
    assert client.get(f'/collaboration/chat/{team_id}').status_code == 401


def test_join_request_acceptance_permissions(client, db):
    signup(client, 'org@example.org', 'organizer')
    login(client, 'org@example.org')
    event_id = event(client, size=2)
    client.post('/logout')
    signup(client, 'leader@example.org', 'participant')
    login(client, 'leader@example.org')
    created = client.post('/participant/register_hackathon', json={'eventId': event_id, 'name': 'Leader',
                        'phone': '101', 'action': 'create', 'teamName': 'Leaders'})
    assert created.status_code == 201
    team_id = created.json['teamId']
    client.post('/logout')
    signup(client, 'joiner@example.org', 'participant')
    login(client, 'joiner@example.org')
    req = client.post('/participant/ai_match_request', json={'eventId': event_id, 'name': 'Joiner', 'phone': '202', 'skills': 'python'})
    assert req.status_code == 201, req.json
    assert client.post(f"/participant/request/{req.json['requestId']}/accept").status_code == 403
    assert client.get(f'/participant/team/{team_id}/status').status_code == 403
    client.post('/logout')
    login(client, 'leader@example.org')
    assert len(client.get(f'/participant/team/{team_id}/requests').json) == 1
    assert client.post(f"/participant/request/{req.json['requestId']}/accept").status_code == 200
    assert client.post(f"/participant/request/{req.json['requestId']}/accept").status_code == 409
    client.post('/logout')
    login(client, 'joiner@example.org')
    assert client.get(f'/participant/team/{team_id}/status').status_code == 200
