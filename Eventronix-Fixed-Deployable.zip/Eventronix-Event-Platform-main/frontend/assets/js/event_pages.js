// Detail pages for hackathons, webinars, workshops, and conferences.
async function loadEventDetails(type) {
  const target = document.getElementById(`${type}Details`);
  if (!target) return;
  try {
    const response = await fetch('/participant/events');
    if (!response.ok) throw new Error('Unable to load events');
    const events = await response.json();
    const id = new URLSearchParams(location.search).get('eventId');
    const event = id ? events.find(e => e._id === id && e.type === type) : events.find(e => e.type === type);
    if (!event) { target.textContent = 'No matching event is currently available.'; return; }
    target.replaceChildren();
    const title = document.createElement('h2'); title.textContent = event.name;
    const description = document.createElement('p'); description.textContent = event.details || 'No details available';
    target.append(title, description);
    window.currentEventId = event._id;
    window.currentEventType = type;
  } catch (error) { target.textContent = error.message; }
}
async function registerEvent(type) {
  const name = document.getElementById('participantName')?.value.trim();
  const phone = document.getElementById('participantPhone')?.value.trim();
  if (!window.currentEventId) return alert('No event selected.');
  if (!name || !phone) return alert('Enter your name and phone number.');
  const body = {eventId: window.currentEventId, name, phone};
  let url = '/participant/register';
  if (type === 'hackathon') {
    url = '/participant/register_hackathon';
    body.skills = document.getElementById('participantSkills')?.value || '';
    body.linkedin = document.getElementById('participantLinkedin')?.value || '';
    body.action = document.getElementById('hackathonAction')?.value || 'create';
    if (body.action === 'create') body.teamName = document.getElementById('teamNameOrCode')?.value.trim();
    if (body.action === 'join') body.teamCode = document.getElementById('teamNameOrCode')?.value.trim();
    if (body.action === 'ai_match') url = '/participant/ai_match_request';
  }
  try {
    const response = await fetch(url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || result.message || 'Registration failed');
    if (result.teamId && body.action !== 'ai_match') localStorage.setItem('currentTeamId', result.teamId);
    if (result.teamCode) localStorage.setItem('currentTeamCode', result.teamCode);
    alert([result.message || 'Successfully registered', result.teamCode ? `Team code: ${result.teamCode}` : ''].filter(Boolean).join('\n'));
    document.getElementById(`${type}RegisterForm`)?.reset();
  } catch (error) {
    alert(error.message);
  }
}
document.addEventListener('DOMContentLoaded', () => {
  for (const type of ['hackathon', 'webinar', 'conference', 'workshop']) {
    const form = document.getElementById(`${type}RegisterForm`);
    if (form) {
      loadEventDetails(type);
      form.addEventListener('submit', e => {e.preventDefault(); registerEvent(type);});
    }
  }
});
