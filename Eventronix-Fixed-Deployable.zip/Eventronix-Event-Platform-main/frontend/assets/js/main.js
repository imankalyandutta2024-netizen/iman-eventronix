// Sign-up and sign-in share one form component and one same-origin API.
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('authForm');
  if (!form) return;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const isSignup = Boolean(document.getElementById('role'));
    const payload = {
      email: document.getElementById('email').value.trim(),
      password: document.getElementById('password').value
    };
    if (isSignup) payload.role = document.getElementById('role').value;
    const button = form.querySelector('[type="submit"]');
    if (button) button.disabled = true;
    try {
      const response = await fetch(isSignup ? '/signup' : '/signin', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        credentials: 'same-origin', body: JSON.stringify(payload)
      });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.message || result.error || 'Authentication failed');
      if (isSignup) {
        alert('Account created. Please sign in.');
        window.location.assign('/signin');
      } else {
        localStorage.setItem('userEmail', result.email);
        const redirect = new URLSearchParams(location.search).get('redirect');
        // Only internal destinations; never allow an open redirect.
        location.assign(redirect && redirect.startsWith('/') && !redirect.startsWith('//') ? redirect : '/');
      }
    } catch (error) {
      alert(error.message || 'Unable to authenticate');
    } finally {
      if (button) button.disabled = false;
    }
  });
});
