// Eventronix collaboration uses authenticated REST calls and short polling.
// No Socket.IO server or CDN is required.
let teamId = '';
let drawing = false;
let lastX = 0, lastY = 0;
let currentColor = '#000000', currentSize = 3, isErasing = false;
const canvas = document.getElementById('whiteboard');
const ctx = canvas ? canvas.getContext('2d') : null;

function setTeamId(id) {
  teamId = (id || '').trim();
  if (!teamId) return;
  const input = document.getElementById('teamIdInput');
  if (input) input.value = teamId;
  const info = document.getElementById('currentTeamInfo');
  if (info) info.textContent = `Your team ID: ${teamId}`;
  loadChat();
  loadPolls();
  redrawStrokes();
}

async function getJSON(url, options) {
  const response = await fetch(url, {credentials: 'same-origin', ...options});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || data.message || `Request failed (${response.status})`);
  return data;
}
function jsonPost(url, body) {
  return getJSON(url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)});
}

async function loadChat() {
  const box = document.getElementById('chatBox');
  if (!teamId || !box) return;
  try {
    const messages = await getJSON(`/collaboration/chat/${encodeURIComponent(teamId)}`);
    box.replaceChildren();
    for (const m of messages) {
      const line = document.createElement('div');
      line.textContent = `${m.sender}: ${m.message}`;
      box.appendChild(line);
    }
    box.scrollTop = box.scrollHeight;
  } catch (error) { console.warn('Chat:', error.message); }
}
async function sendMessage() {
  if (!teamId) return alert('Set a team ID first');
  const input = document.getElementById('chatInput');
  const msg = input?.value.trim();
  if (!msg) return;
  try {
    await jsonPost(`/collaboration/chat/${encodeURIComponent(teamId)}`, {message: msg});
    input.value = '';
    loadChat();
  } catch (error) { alert(error.message); }
}

async function loadPolls() {
  const container = document.getElementById('pollsContainer');
  if (!teamId || !container) return;
  try {
    const polls = await getJSON(`/collaboration/poll/${encodeURIComponent(teamId)}`);
    container.replaceChildren();
    for (const poll of polls) {
      const card = document.createElement('div');
      card.className = 'poll-card';
      const title = document.createElement('strong');
      title.textContent = poll.question;
      card.appendChild(title);
      poll.options.forEach((option, index) => {
        const button = document.createElement('button');
        button.textContent = `${option} (${poll.votes[index]})`;
        button.addEventListener('click', () => vote(poll._id, index));
        card.appendChild(button);
      });
      container.appendChild(card);
    }
  } catch (error) { console.warn('Polls:', error.message); }
}
async function vote(pollId, index) {
  try {
    await jsonPost(`/collaboration/vote/${encodeURIComponent(pollId)}`, {optionIndex: index});
    loadPolls();
  } catch (error) { alert(error.message); }
}

const pollForm = document.getElementById('createPollForm');
if (pollForm) pollForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!teamId) return alert('Set a team ID first');
  const question = document.getElementById('pollQuestion').value.trim();
  const options = document.getElementById('pollOptions').value.split(',').map(s => s.trim()).filter(Boolean);
  if (!question || options.length < 2) return alert('Enter a question and at least two options');
  try {
    await jsonPost(`/collaboration/poll/${encodeURIComponent(teamId)}`, {question, options});
    pollForm.reset();
    loadPolls();
  } catch (error) { alert(error.message); }
});

function resizeCanvas() {
  if (!canvas) return;
  // Keep coordinates consistent across refreshes: work in a fixed logical canvas.
  canvas.width = 1000;
  canvas.height = 700;
  canvas.style.maxWidth = '100%';
  redrawStrokes();
}
function getCoordinates(e) {
  const rect = canvas.getBoundingClientRect();
  const point = e.touches ? e.touches[0] : e;
  return [(point.clientX - rect.left) * canvas.width / rect.width,
          (point.clientY - rect.top) * canvas.height / rect.height];
}
function drawStroke(stroke) {
  if (!ctx) return;
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  ctx.lineWidth = stroke.size; ctx.strokeStyle = stroke.color;
  ctx.globalCompositeOperation = stroke.isErasing ? 'destination-out' : 'source-over';
  ctx.beginPath(); ctx.moveTo(stroke.x1, stroke.y1); ctx.lineTo(stroke.x2, stroke.y2); ctx.stroke();
  ctx.globalCompositeOperation = 'source-over';
}
async function redrawStrokes() {
  if (!ctx || !teamId) return;
  try {
    const strokes = await getJSON(`/collaboration/whiteboard/${encodeURIComponent(teamId)}`);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    strokes.forEach(drawStroke);
  } catch (error) { console.warn('Whiteboard:', error.message); }
}
function startDrawing(e) {
  if (!teamId) return alert('Set a team ID first');
  e.preventDefault();
  drawing = true;
  [lastX, lastY] = getCoordinates(e);
}
function stopDrawing() { drawing = false; }
async function draw(e) {
  if (!drawing || !teamId) return;
  e.preventDefault();
  const [x, y] = getCoordinates(e);
  const stroke = {x1: lastX, y1: lastY, x2: x, y2: y,
                  color: currentColor, size: currentSize, isErasing};
  drawStroke(stroke);
  [lastX, lastY] = [x, y];
  try { await jsonPost(`/collaboration/whiteboard/${encodeURIComponent(teamId)}`, stroke); }
  catch (error) { console.warn('Stroke not saved:', error.message); }
}
function setColor(color) { currentColor = color; isErasing = false; updateToolIndicator(); }
function setSize(size) { currentSize = Math.max(1, Math.min(50, Number(size) || 3)); updateToolIndicator(); }
function toggleEraser() { isErasing = !isErasing; updateToolIndicator(); }
function updateToolIndicator() {
  const label = document.getElementById('toolIndicator');
  if (label) label.textContent = isErasing ? `Eraser (Size: ${currentSize})` : `Pen: ${currentColor} (Size: ${currentSize})`;
}
async function clearCanvas() {
  if (!teamId || !confirm('Clear whiteboard?')) return;
  try {
    await getJSON(`/collaboration/whiteboard/${encodeURIComponent(teamId)}`, {method: 'DELETE'});
    ctx?.clearRect(0, 0, canvas.width, canvas.height);
  } catch (error) { alert(error.message); }
}
if (canvas) {
  resizeCanvas();
  canvas.style.touchAction = 'none';
  canvas.addEventListener('pointerdown', e => {canvas.setPointerCapture(e.pointerId); startDrawing(e);});
  canvas.addEventListener('pointermove', draw);
  canvas.addEventListener('pointerup', stopDrawing);
  canvas.addEventListener('pointercancel', stopDrawing);
  window.addEventListener('resize', redrawStrokes);
}
// Only poll when tab is visible and a team has been selected.
setInterval(() => {
  if (teamId && !document.hidden) { loadChat(); loadPolls(); redrawStrokes(); }
}, 2500);
const savedTeamId = localStorage.getItem('currentTeamId');
if (savedTeamId) setTeamId(savedTeamId);
