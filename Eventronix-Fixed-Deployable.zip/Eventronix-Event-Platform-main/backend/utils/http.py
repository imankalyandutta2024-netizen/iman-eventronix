"""Shared request validation and access control utilities."""
from datetime import datetime, timezone
from functools import wraps
from flask import abort, jsonify, request, session
from bson import ObjectId


def body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400, description='A JSON object is required')
    return data


def required(data, *names):
    for name in names:
        if not isinstance(data.get(name), str) or not data[name].strip():
            abort(400, description=f'{name} is required')
    return data


def oid(value):
    if not ObjectId.is_valid(value):
        abort(400, description='Invalid identifier')
    return ObjectId(value)


def iso_date(value):
    if not value:
        return None
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if result.tzinfo is None:
            # datetime-local inputs from browsers have no timezone; use UTC by
            # convention and document this limitation.
            result = result.replace(tzinfo=timezone.utc)
        return result.astimezone(timezone.utc)
    except (AttributeError, ValueError, TypeError):
        abort(400, description='Invalid ISO datetime')


def utc(value):
    if value is None:
        return None
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def require_login(func):
    @wraps(func)
    def wrapped(*args, **kwargs):
        if not session.get('logged_in'):
            return jsonify(error='Sign in required'), 401
        return func(*args, **kwargs)
    return wrapped


def require_role(role):
    def decorator(func):
        @wraps(func)
        @require_login
        def wrapped(*args, **kwargs):
            if session.get('role') != role:
                return jsonify(error=f'{role.capitalize()} account required'), 403
            return func(*args, **kwargs)
        return wrapped
    return decorator


def json_safe(document):
    """Recursively serializes Mongo ObjectIds/dates without leaking raw BSON."""
    if isinstance(document, ObjectId):
        return str(document)
    if isinstance(document, datetime):
        return document.isoformat() + ('Z' if document.tzinfo is None else '')
    if isinstance(document, dict):
        return {key: json_safe(value) for key, value in document.items()}
    if isinstance(document, list):
        return [json_safe(value) for value in document]
    return document
