"""Lightweight skill-similarity matching without a heavyweight ML runtime."""
from collections import Counter
from math import log, sqrt
import re
from bson.objectid import ObjectId
from backend.config import mongo


def tokens(value):
    return re.findall(r'[a-z0-9+#.]{2,}', str(value or '').lower())


def ai_match_team(event_id, skills):
    teams = list(mongo.db.teams.find({'eventId': ObjectId(event_id), 'submitted': {'$ne': True}}))
    available = [team for team in teams if len(team.get('members', [])) < int(team.get('teamSize') or 4)]
    if not available:
        return None
    documents = [Counter(tokens(' '.join(str(m.get('skills') or '') for m in t.get('members', [])))) for t in available]
    query = Counter(tokens(skills))
    if not query or not any(documents):
        return min(available, key=lambda t: len(t.get('members', [])))
    df = Counter(word for d in documents for word in d)
    n = len(documents)
    def weight(word):
        return log((n + 1) / (df[word] + 1)) + 1
    q_norm = sqrt(sum((count * weight(word)) ** 2 for word, count in query.items()))
    def score(doc):
        d_norm = sqrt(sum((count * weight(word)) ** 2 for word, count in doc.items()))
        if not d_norm or not q_norm:
            return 0
        return sum(query[word] * count * weight(word) ** 2 for word, count in doc.items()) / (q_norm * d_norm)
    ranked = [(score(doc), -len(available[i].get('members', [])), i) for i, doc in enumerate(documents)]
    return available[max(ranked)[2]]
