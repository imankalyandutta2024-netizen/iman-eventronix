"""Application configuration. Production requires a stable SECRET_KEY and MongoDB."""
import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask
from flask_pymongo import PyMongo
from flask_cors import CORS

load_dotenv(Path(__file__).resolve().parent.parent / '.env')

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv('SECRET_KEY', 'local-development-only-change-me'),
    MONGO_URI=os.getenv('MONGO_URI', 'mongodb://localhost:27017/eventronix'),
    JSON_SORT_KEYS=False,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.getenv('SESSION_COOKIE_SECURE', 'false').lower() == 'true',
)
if os.getenv('FLASK_DEBUG', '').lower() not in ('true', '1') and not os.getenv('SECRET_KEY'):
    # Avoid a guessed/shared signing key in production. Tests set a test key.
    raise RuntimeError('SECRET_KEY must be configured; see .env.example')

# Same-origin frontend doesn't require permissive CORS. Only explicitly configured
# third-party origins receive cross-origin credentials.
origins = [o.strip() for o in os.getenv('CORS_ORIGINS', '').split(',') if o.strip()]
if origins:
    CORS(app, origins=origins, supports_credentials=True)

mongo = PyMongo(app)
