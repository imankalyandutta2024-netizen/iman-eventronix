from backend.config import mongo
from pymongo.errors import DuplicateKeyError
from werkzeug.security import generate_password_hash, check_password_hash


def create_user(email, password, role):
    users = mongo.db.users
    users.create_index('email', unique=True)
    try:
        return users.insert_one({'email': email, 'password': generate_password_hash(password), 'role': role}).inserted_id
    except DuplicateKeyError:
        return None


def authenticate_user(email, password):
    user = mongo.db.users.find_one({'email': email})
    if user and check_password_hash(user['password'], password):
        return {'email': user['email'], 'role': user['role']}
    return None


def get_user(email):
    return mongo.db.users.find_one({'email': email})
