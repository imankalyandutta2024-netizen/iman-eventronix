"""Eventronix HTTP app: API blueprints, static frontend and health checks."""
import os
from pathlib import Path
from flask import abort, jsonify, send_from_directory
from werkzeug.exceptions import HTTPException
from pymongo.errors import PyMongoError
from backend.config import app, mongo
from backend.routes.auth import auth_bp
from backend.routes.organizer import organizer_bp
from backend.routes.participant import participant_bp
from backend.routes.collaboration import collab_bp
from backend.routes.virtual_event import virtual_bp

for blueprint in (auth_bp, organizer_bp, participant_bp, collab_bp, virtual_bp):
    app.register_blueprint(blueprint)

FRONTEND_DIR = Path(__file__).resolve().parent.parent / 'frontend'


@app.get('/healthz')
def health():
    """Liveness probe: web process is running (no DB dependency)."""
    return jsonify(status='ok')


@app.get('/readyz')
def readiness():
    """Readiness includes the database needed by business endpoints."""
    try:
        mongo.cx.admin.command('ping')
        return jsonify(status='ready')
    except PyMongoError:
        return jsonify(status='unavailable', database='unreachable'), 503


@app.get('/')
def home():
    return send_from_directory(FRONTEND_DIR, 'common_dashboard.html')


@app.get('/signin')
@app.get('/signup')
@app.get('/organizer_dashboard')
@app.get('/participant_dashboard')
@app.get('/virtual_event')
def shortcuts():
    from flask import request
    return send_from_directory(FRONTEND_DIR, request.path.lstrip('/') + '.html')


@app.get('/assets/<path:path>')
def assets(path):
    return send_from_directory(FRONTEND_DIR / 'assets', path)


@app.get('/<path:path>')
def pages(path):
    if not (path.endswith('.html') or path.endswith('.css') or path.endswith('.js')):
        abort(404)
    return send_from_directory(FRONTEND_DIR, path)


@app.errorhandler(HTTPException)
def api_errors(error):
    from flask import request
    if request.path.startswith(('/organizer/', '/participant/', '/collaboration/', '/auth/', '/signup', '/signin', '/readyz')) and request.method != 'GET' or request.path.startswith(('/organizer/', '/participant/', '/collaboration/', '/auth/', '/readyz')):
        return jsonify(error=error.description), error.code
    return error


@app.errorhandler(PyMongoError)
def database_error(error):
    app.logger.exception('Database operation failed')
    return jsonify(error='Database temporarily unavailable'), 503


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', '5000')),
            debug=os.getenv('FLASK_DEBUG', '').lower() in ('1', 'true'))
