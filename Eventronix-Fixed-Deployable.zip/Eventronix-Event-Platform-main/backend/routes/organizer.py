"""Organizer API. Organizer-owned events are scoped to their creator."""
import csv
import io
from datetime import datetime, timezone
from flask import Blueprint, Response, abort, jsonify, request, session
from backend.config import mongo
from backend.utils.ai_roadmap import generate_roadmap
from backend.utils.http import body, iso_date, json_safe, oid, required, require_role, utc

organizer_bp = Blueprint('organizer', __name__)


def owned_event(event_id):
    event = mongo.db.events.find_one({'_id': oid(event_id)})
    if not event:
        abort(404, description='Event not found')
    if event.get('organizerEmail') != session['email']:
        abort(403, description='This event belongs to another organizer')
    return event


@organizer_bp.route('/organizer/create_event', methods=['POST'])
@require_role('organizer')
def create_event():
    data = required(body(), 'name', 'type')
    if data['type'] not in ('hackathon', 'webinar', 'workshop', 'conference'):
        return jsonify(error='Unsupported event type'), 400
    try:
        team_size = int(data.get('teamSize') or 4)
    except (ValueError, TypeError):
        return jsonify(error='Invalid team size'), 400
    if not 1 <= team_size <= 100:
        return jsonify(error='Team size must be 1–100'), 400
    now = datetime.now(timezone.utc)
    event_id = mongo.db.events.insert_one({
        'name': data['name'].strip(), 'type': data['type'],
        'details': str(data.get('details') or '')[:10000], 'teamSize': team_size,
        'organizerEmail': session['email'],
        'registrationDeadline': iso_date(data.get('registrationDeadline')),
        'createdAt': now, 'updatedAt': now,
    }).inserted_id
    return jsonify(message='Event created', eventId=str(event_id)), 201


@organizer_bp.route('/organizer/events')
@require_role('organizer')
def events():
    return jsonify(json_safe(list(mongo.db.events.find({'organizerEmail': session['email']}))))


@organizer_bp.route('/organizer/event/<event_id>')
@require_role('organizer')
def get_event(event_id):
    return jsonify(json_safe(owned_event(event_id)))


@organizer_bp.route('/organizer/event/<event_id>/deadline', methods=['POST'])
@require_role('organizer')
def update_deadline(event_id):
    event = owned_event(event_id)
    data = body()
    if 'deadline' not in data:
        return jsonify(error='deadline is required'), 400
    mongo.db.events.update_one({'_id': event['_id']}, {'$set': {
        'registrationDeadline': iso_date(data['deadline']), 'updatedAt': datetime.now(timezone.utc)
    }})
    return jsonify(message='Deadline updated successfully')


@organizer_bp.route('/organizer/event/<event_id>/registration_status')
@require_role('organizer')
def registration_status(event_id):
    event = owned_event(event_id)
    deadline = utc(event.get('registrationDeadline'))
    return jsonify(registrationOpen=deadline is None or deadline >= datetime.now(timezone.utc),
                   deadline=deadline.isoformat() if deadline else None,
                   participantsCount=mongo.db.registrations.count_documents({'eventId': event['_id']}))


@organizer_bp.route('/organizer/<event_id>/participants')
@require_role('organizer')
def participants(event_id):
    event = owned_event(event_id)
    return jsonify(json_safe(list(mongo.db.registrations.find({'eventId': event['_id']}))))


@organizer_bp.route('/organizer/<event_id>/teams')
@require_role('organizer')
def teams(event_id):
    event = owned_event(event_id)
    return jsonify(json_safe(list(mongo.db.teams.find({'eventId': event['_id']}))))


@organizer_bp.route('/organizer/<event_id>/analytics')
@require_role('organizer')
def analytics(event_id):
    event = owned_event(event_id)
    return jsonify(participant_count=mongo.db.registrations.count_documents({'eventId': event['_id']}),
                   team_count=mongo.db.teams.count_documents({'eventId': event['_id']}))


@organizer_bp.route('/organizer/<event_id>/export')
@require_role('organizer')
def export_csv(event_id):
    event = owned_event(event_id)
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=['name', 'email', 'phone', 'skills', 'linkedin'])
    writer.writeheader()
    for entry in mongo.db.registrations.find({'eventId': event['_id']}):
        # Prevent spreadsheet formula injection when CSVs are opened in Excel.
        writer.writerow({k: "'" + str(entry.get(k, '')) if str(entry.get(k, '')).startswith(('=', '+', '-', '@')) else str(entry.get(k, ''))
                         for k in writer.fieldnames})
    response = Response(output.getvalue(), mimetype='text/csv; charset=utf-8')
    response.headers['Content-Disposition'] = f'attachment; filename=participants_{event_id}.csv'
    return response


@organizer_bp.route('/organizer/<event_id>/ai_roadmap')
@require_role('organizer')
def ai_roadmap(event_id):
    event = owned_event(event_id)
    return jsonify(event=event['name'], roadmap=generate_roadmap(event['type']))


@organizer_bp.route('/organizer/<event_id>/submitted_teams')
@require_role('organizer')
def submitted_teams(event_id):
    event = owned_event(event_id)
    return jsonify(json_safe(list(mongo.db.teams.find({'eventId': event['_id'], 'submitted': True}))))


@organizer_bp.route('/organizer/submitted-teams')
@require_role('organizer')
def get_submitted_teams():
    events = list(mongo.db.events.find({'organizerEmail': session['email']}))
    allowed_ids = {e['_id'] for e in events}
    event_id = request.args.get('eventId')
    if event_id:
        owned_event(event_id)
        allowed_ids &= {oid(event_id)}
    teams = list(mongo.db.teams.find({'eventId': {'$in': list(allowed_ids)}, 'submitted': True}).sort('submittedAt', -1))
    event_names = {e['_id']: e['name'] for e in events}
    for team in teams:
        team['eventName'] = event_names.get(team['eventId'], 'Unknown Event')
        team.setdefault('teamCode', 'N/A')
        team.setdefault('status', 'pending')
    return jsonify(json_safe(teams))
