"""Team collaboration via MongoDB-backed REST polling (no WebSocket dependency)."""
from datetime import datetime, timezone
from flask import Blueprint, abort, jsonify, request, session
from backend.config import mongo
from backend.utils.http import body, json_safe, oid, required, require_login

collab_bp = Blueprint('collab', __name__)


def team_access(team_id):
    team = mongo.db.teams.find_one({'_id': oid(team_id)})
    if not team:
        abort(404, description='Team not found')
    if not any(m.get('email') == session['email'] for m in team.get('members', [])):
        abort(403, description='Only team members can collaborate')
    return team


@collab_bp.route('/collaboration/chat/<team_id>', methods=['GET', 'POST'])
@require_login
def chat(team_id):
    team_access(team_id)
    if request.method == 'POST':
        data = required(body(), 'message')
        mongo.db.chat.insert_one({'teamId': team_id, 'sender': session['email'],
                                  'message': data['message'].strip()[:2000],
                                  'createdAt': datetime.now(timezone.utc)})
        return jsonify(message='Sent'), 201
    messages = mongo.db.chat.find({'teamId': team_id}).sort('_id', -1).limit(100)
    return jsonify(json_safe(list(reversed(list(messages)))))


@collab_bp.route('/collaboration/poll/<team_id>', methods=['GET', 'POST'])
@require_login
def poll(team_id):
    team_access(team_id)
    if request.method == 'POST':
        data = required(body(), 'question')
        options = data.get('options')
        if not isinstance(options, list) or not 2 <= len(options) <= 12 or not all(isinstance(x, str) and x.strip() for x in options):
            return jsonify(error='Provide 2–12 nonempty options'), 400
        mongo.db.polls.insert_one({'teamId': team_id, 'question': data['question'][:500],
                                   'options': [x[:200].strip() for x in options],
                                   'votes': [0] * len(options), 'voters': []})
        return jsonify(message='Poll created'), 201
    polls = list(mongo.db.polls.find({'teamId': team_id}))
    for p in polls:
        p.pop('voters', None)
    return jsonify(json_safe(polls))


@collab_bp.route('/collaboration/vote/<poll_id>', methods=['POST'])
@require_login
def vote(poll_id):
    data = body()
    poll_id_obj = oid(poll_id)
    p = mongo.db.polls.find_one({'_id': poll_id_obj})
    if not p:
        return jsonify(error='Poll not found'), 404
    team_access(p['teamId'])
    index = data.get('optionIndex')
    if type(index) is not int or index < 0 or index >= len(p['options']):
        return jsonify(error='Invalid option'), 400
    update = mongo.db.polls.update_one({'_id': poll_id_obj, 'voters': {'$ne': session['email']}},
                                       {'$inc': {f'votes.{index}': 1}, '$addToSet': {'voters': session['email']}})
    if not update.modified_count:
        return jsonify(error='You already voted'), 409
    return jsonify(message='Voted')


@collab_bp.route('/collaboration/whiteboard/<team_id>', methods=['GET', 'POST', 'DELETE'])
@require_login
def whiteboard(team_id):
    team_access(team_id)
    if request.method == 'DELETE':
        mongo.db.whiteboard.delete_many({'teamId': team_id})
        return jsonify(message='Whiteboard cleared')
    if request.method == 'POST':
        data = body()
        try:
            coordinates = {key: float(data[key]) for key in ('x1', 'y1', 'x2', 'y2')}
            size = int(data.get('size', 3))
            if not 1 <= size <= 50 or any(abs(v) > 100000 for v in coordinates.values()):
                raise ValueError()
        except (ValueError, TypeError, KeyError):
            return jsonify(error='Invalid stroke'), 400
        stroke = {'teamId': team_id, **coordinates, 'color': str(data.get('color', '#000000'))[:32],
                  'size': size, 'isErasing': bool(data.get('isErasing', False)),
                  'timestamp': datetime.now(timezone.utc)}
        mongo.db.whiteboard.insert_one(stroke)
        return jsonify(message='Stroke saved'), 201
    strokes = list(mongo.db.whiteboard.find({'teamId': team_id}).sort('_id', 1).limit(5000))
    return jsonify(json_safe(strokes))
