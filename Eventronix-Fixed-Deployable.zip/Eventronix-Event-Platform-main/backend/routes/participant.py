"""Participant registrations, teams, capacity-safe membership and join requests."""
import secrets
import string
from datetime import datetime, timezone
from flask import Blueprint, abort, jsonify, request, session
from bson import ObjectId
from backend.config import mongo
from backend.utils.ai_team_matching import ai_match_team
from backend.utils.http import body, json_safe, oid, required, require_login, utc

participant_bp = Blueprint('participant', __name__)


def event_from(data):
    event = mongo.db.events.find_one({'_id': oid(data.get('eventId'))})
    if not event:
        abort(404, description='Event not found')
    deadline = utc(event.get('registrationDeadline'))
    if deadline and deadline < datetime.now(timezone.utc):
        abort(400, description='Registration is closed for this event')
    return event


def registration_fields(data, event):
    required(data, 'name', 'phone')
    return {'eventId': event['_id'], 'name': data['name'].strip(),
            'phone': data['phone'].strip(), 'email': session['email'],
            'skills': str(data.get('skills') or ''), 'linkedin': str(data.get('linkedin') or '')}


def register_once(info, team_id=None):
    lookup = {'eventId': info['eventId'], 'email': info['email']}
    if mongo.db.registrations.find_one(lookup):
        abort(409, description='Already registered for this event')
    if team_id:
        info['teamId'] = team_id
    mongo.db.registrations.insert_one(info)


def team_member(team):
    return any(m.get('email') == session.get('email') for m in team.get('members', []))


def member_team(team_id):
    team = mongo.db.teams.find_one({'_id': oid(team_id)})
    if not team:
        abort(404, description='Team not found')
    if not team_member(team):
        abort(403, description='Only team members can access this resource')
    return team


def append_member(team, info):
    """Use one atomic conditional update to prevent oversubscribing team capacity."""
    member = {k: info[k] for k in ('name', 'phone', 'email', 'skills', 'linkedin')}
    size = int(team.get('teamSize') or 4)
    update = mongo.db.teams.update_one({
        '_id': team['_id'], 'submitted': {'$ne': True},
        'members.email': {'$ne': info['email']},
        f'members.{size - 1}': {'$exists': False},
    }, {'$push': {'members': member}})
    if not update.modified_count:
        abort(409, description='Team is full, submitted, or you already joined')


def generate_team_code():
    alphabet = string.ascii_uppercase + string.digits
    for _ in range(20):
        code = ''.join(secrets.choice(alphabet) for _ in range(8))
        if not mongo.db.teams.find_one({'teamCode': code}):
            return code
    abort(503, description='Unable to generate unique team code')


@participant_bp.route('/participant/events')
def get_events():
    event_type = request.args.get('type')
    query = {'type': event_type} if event_type and event_type != 'all' else {}
    events = list(mongo.db.events.find(query))
    for event in events:
        event.pop('organizerEmail', None)
    return jsonify(json_safe(events))


@participant_bp.route('/participant/register', methods=['POST'])
@require_login
def register():
    data = body()
    event = event_from(data)
    info = registration_fields(data, event)
    register_once(info)
    return jsonify(message='Registered successfully'), 201


@participant_bp.route('/participant/register_hackathon', methods=['POST'])
@require_login
def hackathon():
    data = body()
    event = event_from(data)
    if event['type'] != 'hackathon':
        return jsonify(error='This is not a hackathon event'), 400
    info = registration_fields(data, event)
    if mongo.db.registrations.find_one({'eventId': event['_id'], 'email': session['email']}):
        return jsonify(error='Already registered for this event'), 409
    action = data.get('action')
    if action == 'create':
        required(data, 'teamName')
        size = int(event.get('teamSize') or 4)
        team = {'eventId': event['_id'], 'teamName': data['teamName'].strip(),
                'teamCode': generate_team_code(), 'teamSize': size,
                'members': [{k: info[k] for k in ('name', 'phone', 'email', 'skills', 'linkedin')}],
                'createdBy': session['email'], 'submitted': False}
        team_id = mongo.db.teams.insert_one(team).inserted_id
        register_once(info, team_id)
        return jsonify(message='Team created successfully', teamCode=team['teamCode'], teamId=str(team_id)), 201
    if action == 'join':
        required(data, 'teamCode')
        team = mongo.db.teams.find_one({'teamCode': data['teamCode'].strip().upper(), 'eventId': event['_id']})
        if not team:
            return jsonify(error='Team not found in this event'), 404
    elif action == 'ai_match':
        team = ai_match_team(event['_id'], info['skills'])
        if not team:
            return jsonify(message='No available teams'), 200
    else:
        return jsonify(error='Invalid action'), 400
    append_member(team, info)
    register_once(info, team['_id'])
    return jsonify(message='Joined team successfully', teamCode=team.get('teamCode', ''), teamId=str(team['_id']))


@participant_bp.route('/participant/teams/<event_id>')
@require_login
def get_teams(event_id):
    teams = list(mongo.db.teams.find({'eventId': oid(event_id)}))
    for team in teams:
        if not team_member(team):
            team.pop('teamCode', None)
            team.pop('createdBy', None)
            # Private member contact details should not be exposed to unrelated users.
            team['members'] = [{'name': m.get('name', ''), 'skills': m.get('skills', '')} for m in team.get('members', [])]
        team.pop('joinRequests', None)
    return jsonify(json_safe(teams))


@participant_bp.route('/participant/team/<team_id>/submit', methods=['POST'])
@require_login
def submit_team(team_id):
    team = member_team(team_id)
    if team.get('submitted'):
        return jsonify(message='Team already submitted', submitted=True)
    mongo.db.teams.update_one({'_id': team['_id']}, {'$set': {
        'submitted': True, 'submittedAt': datetime.now(timezone.utc),
        'updatedAt': datetime.now(timezone.utc)}})
    return jsonify(message='Team submitted successfully')


@participant_bp.route('/participant/team/<team_id>/status')
@require_login
def team_status(team_id):
    team = member_team(team_id)
    return jsonify(json_safe({'submitted': team.get('submitted', False),
                              'submittedAt': team.get('submittedAt'), 'members': team.get('members', [])}))


@participant_bp.route('/participant/ai_match_request', methods=['POST'])
@require_login
def ai_match_request():
    data = body()
    event = event_from(data)
    if event['type'] != 'hackathon':
        return jsonify(error='Only hackathons support team matching'), 400
    info = registration_fields(data, event)
    if mongo.db.registrations.find_one({'eventId': event['_id'], 'email': session['email']}):
        return jsonify(error='Already registered'), 409
    team = ai_match_team(event['_id'], info['skills'])
    if not team:
        return jsonify(message='No suitable teams found')
    existing = mongo.db.requests.find_one({'eventId': event['_id'], 'email': session['email'], 'status': 'pending'})
    if existing:
        return jsonify(message='Join request already pending', teamId=str(existing['teamId']), requestId=str(existing['_id']))
    info.update(teamId=team['_id'], status='pending', createdAt=datetime.now(timezone.utc))
    request_id = mongo.db.requests.insert_one(info).inserted_id
    return jsonify(message=f"Request sent to {team['teamName']}", teamId=str(team['_id']), requestId=str(request_id)), 201


@participant_bp.route('/participant/team/<team_id>/requests')
@require_login
def get_team_requests(team_id):
    team = member_team(team_id)
    return jsonify(json_safe(list(mongo.db.requests.find({'teamId': team['_id'], 'status': 'pending'}))))


def decide_request(request_id, accept):
    req = mongo.db.requests.find_one({'_id': oid(request_id)})
    if not req:
        abort(404, description='Request not found')
    team = member_team(str(req['teamId']))
    if team.get('createdBy') != session['email']:
        abort(403, description='Only the team creator may decide join requests')
    if req['status'] != 'pending':
        abort(409, description='Request already handled')
    if accept:
        if mongo.db.registrations.find_one({'eventId': req['eventId'], 'email': req['email']}):
            return jsonify(error='Participant already registered'), 409
        append_member(team, req)
        register_once({k: req[k] for k in ('eventId', 'name', 'phone', 'email', 'skills', 'linkedin')}, team['_id'])
    mongo.db.requests.update_one({'_id': req['_id'], 'status': 'pending'}, {'$set': {
        'status': 'accepted' if accept else 'rejected', 'resolvedAt': datetime.now(timezone.utc)}})
    return jsonify(message='Request accepted' if accept else 'Request rejected')


@participant_bp.route('/participant/request/<request_id>/accept', methods=['POST'])
@require_login
def accept_request(request_id):
    return decide_request(request_id, True)


@participant_bp.route('/participant/request/<request_id>/reject', methods=['POST'])
@require_login
def reject_request(request_id):
    return decide_request(request_id, False)
