from pathlib import Path
from flask import Blueprint, abort, send_from_directory

virtual_bp = Blueprint('virtual', __name__)
VIDEO_FOLDER = Path(__file__).resolve().parents[2] / 'frontend' / 'assets' / 'videos'


@virtual_bp.route('/virtual/video/<path:video_name>')
def serve_video(video_name):
    if not video_name.lower().endswith('.mp4'):
        abort(404)
    return send_from_directory(VIDEO_FOLDER, video_name, mimetype='video/mp4')
