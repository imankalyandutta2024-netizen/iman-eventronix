from flask import Blueprint, jsonify, request, session
from backend.models.user import create_user, authenticate_user
from backend.utils.http import body, required

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = required(body(), 'email', 'password', 'role')
    email = data['email'].strip().lower()
    if '@' not in email or '.' not in email.split('@')[-1]:
        return jsonify(success=False, message='Valid email required'), 400
    if len(data['password']) < 8:
        return jsonify(success=False, message='Password must have at least 8 characters'), 400
    if data['role'] not in ('organizer', 'participant'):
        return jsonify(success=False, message='Invalid role'), 400
    user_id = create_user(email, data['password'], data['role'])
    if user_id is None:
        return jsonify(success=False, message='User already exists'), 409
    return jsonify(success=True, message='Account created. Please sign in.'), 201


@auth_bp.route('/signin', methods=['POST'])
def signin():
    data = required(body(), 'email', 'password')
    user = authenticate_user(data['email'].strip().lower(), data['password'])
    if not user:
        return jsonify(success=False, message='Invalid credentials'), 401
    session.clear()
    session.update(logged_in=True, email=user['email'], role=user['role'])
    return jsonify(success=True, redirect='/', role=user['role'], email=user['email'])


@auth_bp.route('/auth/check_session')
def check_session():
    if session.get('logged_in'):
        return jsonify(loggedIn=True, user={'email': session['email'], 'role': session['role']})
    return jsonify(loggedIn=False)


@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify(success=True, message='Logged out successfully')
